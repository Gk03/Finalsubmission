class Shift < ApplicationRecord
    belongs_to :store, optional: true
    belongs_to :department, optional: true
    
    belongs_to :user, optional: true

    validates :start, presence: {message: 'is required'}
    validates :end, presence: {message: 'is required'}
    validates :date, presence: {message: 'is required'}
    validates :store, presence: {message: 'is required'}
    validates :department, presence: {message: 'is required'}
end
