class Store < ApplicationRecord
    has_many :storedepartments
    has_many :departments, through: :storedepartments

    validates :name, presence: true
    validates :address, presence: true
end
