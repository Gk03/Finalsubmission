class Notification < ApplicationRecord
end
