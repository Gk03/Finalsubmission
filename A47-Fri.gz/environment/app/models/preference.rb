class Preference < ApplicationRecord
    belongs_to :department
    belongs_to :store
    belongs_to :user
end
