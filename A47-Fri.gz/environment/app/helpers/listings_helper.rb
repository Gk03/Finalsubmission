module ListingsHelper
  def getPreferenceScore(shift, prefs)
    if prefs != nil
      preferred = prefs.select {|p| p.department.id == shift.department.id}.first
      if preferred == nil
        'Low'
      elsif preferred.score == 3
        'Perfect'
      elsif preferred.score == 2
        'High'
      else
        'Medium'
      end
    end
  end

  def canSelect(shift)
    userShifts = Shift.where(user_id: session[:user_id], date: shift.date)
    puts userShifts
    if userShifts == nil || userShifts.length == 0
      true
    else
      false
    end
  end
end
