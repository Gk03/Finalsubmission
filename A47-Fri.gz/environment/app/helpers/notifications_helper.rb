module NotificationsHelper
    def notifications
        @user = User.find(session[:user_id])
        if @user.manager == false
            @notifications = Notification.where(manager: false)
        else
            @notifications = Notification.where(store_id: @user.store.id)
        end
    end
end
