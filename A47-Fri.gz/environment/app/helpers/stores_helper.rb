module StoresHelper
    def all_stores
        @stores = Store.all
    end
    
    def departments_by_store(store_id)
        store = Store.includes(:departments).find_by_id(:store_id)
        departments = store.departments
    end

    def all_departments
        departments = Department.all
    end
end
