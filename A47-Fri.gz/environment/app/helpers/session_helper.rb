module SessionHelper
    def logged_in
        session[:user_id] != nil
    end

    def is_admin
        user = User.find(session[:user_id])
        user.admin == true
    end
end
