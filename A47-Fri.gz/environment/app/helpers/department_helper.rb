module DepartmentHelper
end
