class ListingsController < ApplicationController
  include StoresHelper
  include ListingsHelper

  before_action :authenticate
  def authenticate
    if !logged_in
      redirect_to login_path
    end
  end

  def new
    @errors = nil
  end

  def create
    store = params[:store]
    department = params[:department]
    date = params[:date]
    start = params[:start]
    endTime = params[:end]
    
    shift = Shift.new
    shift.store_id = store
    shift.department_id = department
    shift.date = date
    shift.start = start
    shift.end = endTime
    shift.active = true

    if shift.valid?
      shift.save
      department = Department.find_by_id(department)
      message = "A new shift for #{date} from #{start} - #{endTime} has been posted in #{department.name} department"
      
      Notification.create({store_id: store, message: message, manager: false, active: true });

      redirect_to listings_path
    else
      @errors = shift.errors.full_messages
      render "new"
    end
  end

  def update
    if params[:shift] != nil
      shift = Shift.find_by_id(params[:shift])
      shift.user_id = session[:user_id]
      shift.taken = true
      shift.save
      
      user = User.find_by_id(session[:user_id])
      message = "#{user.name} has taken shift from #{I18n.l(shift.start, format: '%I:%M %p')} - #{I18n.l(shift.end, format: '%I:%M %p')} in #{shift.department.name} department"
     
      puts message

      Notification.create({store_id: shift.store.id, message: message, manager: true, active: true });

      redirect_to listings_path
    else
      redirect_to listings_path
    end
  end

  def list
    @shifts = Shift.all
    @preferences = Preference.where(user_id: session[:user_id])
  end

  def departments
    store_id = params[:store]
    if store_id != nil
      render :json => all_departments
    else
      render :json => departments_by_store(store_id)
    end
  end
end
