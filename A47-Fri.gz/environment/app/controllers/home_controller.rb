class HomeController < ApplicationController
  before_action :authenticate
  
  def authenticate
    if !logged_in
      redirect_to login_path
    end
  end

  def index
    @user = User.find(session[:user_id])
    if is_admin
      redirect_to admin_home_path
    end
    @shifts = Shift.where(user_id: session[:user_id])
  end
end
