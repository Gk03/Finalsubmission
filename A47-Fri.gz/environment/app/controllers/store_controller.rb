class StoreController < ApplicationController
  before_action :authenticate
  def authenticate
    if !logged_in
      redirect_to login_path
    else
      if !is_admin
        redirect_to root_url
      end 
    end
  end

  def new
    @errors = nil
    @stores = Store.all
  end

  def create
    name = params[:name]
    address = params[:address]
    
    store = Store.new
    store.name = name
    store.address = address

    if store.valid?
      store.active = true
      store.save

      depts = Department.all
      depts.each do |dept|
        Storedepartment.create({store_id: store.id, department_id: dept.id})
      end

      redirect_to store_path
    else
      @errors = store.errors.full_messages
      @stores = Store.all
      render "new"
    end
  end

  def activate
    store = Store.find(params[:store])
    store.active = true
    store.save
    redirect_to store_path
  end

  def deactivate
    store = Store.find(params[:store])
    store.active = false
    store.save
    redirect_to store_path
  end
end
