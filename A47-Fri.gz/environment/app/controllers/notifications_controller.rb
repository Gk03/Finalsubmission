class NotificationsController < ApplicationController
  before_action :authenticate
  
  def authenticate
    if !logged_in
      redirect_to login_path
    end
  end
  
  def list
  end
end
