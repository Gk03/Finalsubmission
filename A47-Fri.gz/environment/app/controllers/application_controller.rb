class ApplicationController < ActionController::Base
    include SessionHelper
    include NotificationsHelper
end
