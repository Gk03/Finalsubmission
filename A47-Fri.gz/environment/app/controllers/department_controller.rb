class DepartmentController < ApplicationController
  before_action :authenticate
  def authenticate
    if !logged_in
      redirect_to login_path
    else
      if !is_admin
        redirect_to root_url
      end 
    end
  end

  def new
    @errors = nil
    @departments = Department.all
  end

  def create
    name = params[:name]
    store = params[:store]
    
    department = Department.new
    department.name = name

    if department.valid?
      department.active = true
      department.save

      stores = Store.all

      stores.each do |store|
        storedept = Storedepartment.create({store_id: store.id, department_id: department.id})
      end

      redirect_to department_path
    else
      @errors = department.errors.full_messages
      @departments = Department.all
      render "new"
    end
  end

  def activate
    department = Department.find(params[:department])
    department.active = true
    department.save

    stores = Store.all

    stores.each do |store|
      storedept = Storedepartment.create({store_id: store.id, department_id: department.id})
    end
  
    redirect_to department_path
  end

  def deactivate
    department = Department.find(params[:department])
    department.active = false
    department.save

    storedepts = Storedepartment.where(department_id: department.id)
    if storedepts != nil
      storedepts.each do |stdpt|
        stdpt.delete
      end    
    end

    redirect_to department_path
  end
end
