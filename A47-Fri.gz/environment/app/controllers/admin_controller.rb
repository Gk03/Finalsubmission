class AdminController < ApplicationController
  before_action :authenticate
  def authenticate
    if !logged_in
      redirect_to login_path
    else
      if !is_admin
        redirect_to root_url
      end 
    end
  end

  def index
    @user = User.find(session[:user_id])
  end
end
#authentication to make sure only logged in admin staff have access to admin functionalities