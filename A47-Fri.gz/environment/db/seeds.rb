# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
puts 'Creating Departments'
dep1 = Department.create({name: 'Sales', active: true})
dep2 = Department.create({name: 'Billing', active: true})
dep3 = Department.create({name: 'Housekeeping', active: true})
dep4 = Department.create({name: 'Security', active: true})

puts 'Creating Stores'
store1 = Store.create({name: 'Elizabeth Street', address: 'Elizabeth Street, Melbourne', active: true})
store2 = Store.create({name: 'Swanston Street', address: 'Swanston Street, Melbourne', active: true})

puts 'Creating Store Departments'
storedepartments = Storedepartment.create([
    {store_id: store1.id, department_id: dep1.id},
    {store_id: store1.id, department_id: dep2.id},
    {store_id: store1.id, department_id: dep3.id},
    {store_id: store1.id, department_id: dep4.id},
    {store_id: store2.id, department_id: dep1.id},
    {store_id: store2.id, department_id: dep2.id},
    {store_id: store2.id, department_id: dep3.id},
    {store_id: store2.id, department_id: dep4.id}])

puts 'Creating Users'
anna = User.create({name: 'Anna', email:'anna@junctions.com', password: 'anna@123', active: true, manager: false, store_id: store1.id})
jennifer = User.create({name: 'Jennifer', email:'jennifer@junctions.com', password: 'jennifer@123', active: true, manager: true, store_id: store1.id})

puts 'Creating Admin'
admin = User.create({name: 'Admin', email: 'admin@junctions.com', password: 'admin@632', active: true, admin: true, store_id: store1.id});

puts 'Creating Shifts'
shifts = Shift.create([
    {date: '13/11/2019', start: '08:00', end: '13:00', store_id: store1.id, department_id: dep1.id, taken: false},
    {date: '13/11/2019', start: '13:00', end: '18:00', store_id: store1.id, department_id: dep2.id, taken: false},
    {date: '14/11/2019', start: '06:00', end: '11:00', store_id: store2.id, department_id: dep2.id, taken: false},
    {date: '14/11/2019', start: '11:00', end: '16:00', store_id: store2.id, department_id: dep3.id, taken: false},
    {date: '14/11/2019', start: '16:00', end: '21:00', store_id: store2.id, department_id: dep4.id, taken: false}])

puts 'Creating Preferences'
preferences = Preference.create([
    {user_id: anna.id, store_id: store1.id, department_id: dep1.id, score: 3},
    {user_id: anna.id, store_id: store1.id, department_id: dep2.id, score: 2},
    {user_id: anna.id, store_id: store2.id, department_id: dep3.id, score: 1}])