class CreateStoredepartments < ActiveRecord::Migration[6.0]
  def change
    create_table :storedepartments do |t|
      t.belongs_to :store
      t.belongs_to :department
      
      t.timestamps
    end
  end
end
