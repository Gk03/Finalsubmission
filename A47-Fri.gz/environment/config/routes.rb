Rails.application.routes.draw do
  root 'home#index'
  
  get 'signup', to: 'users#new', as: 'signup'
  post 'signup', to: 'users#create', as: 'signup_post'

  get 'login', to: 'session#new', as: 'login'
  post 'login', to: 'session#create', as: 'login_post'
  get 'logout', to: 'session#destroy', as: 'logout'
  
  get 'shifts', to: 'listings#list', as: 'listings'
  get 'add-shift', to: 'listings#new', as: 'listing'
  post 'add-shift', to: 'listings#create', as: 'listing_post'
  post 'update-shift', to: 'listings#update', as: 'listing_update'

  get 'departments', to: 'listings#departments', as: 'get_departments'

  get 'notifications', to: 'notifications#list', as: 'notifications'
  
  get 'home', to: 'home#index', as: 'home'

  get 'admin', to: 'admin#index', as: 'admin_home'

  get 'store', to: 'store#new', as: 'store'
  post 'store', to: 'store#create', as: 'store_post'
  post 'activate_store', to: 'store#activate', as: 'activate_store'
  post 'deactivate_store', to: 'store#deactivate', as: 'deactivate_store'

  get 'department', to: 'department#new', as: 'department'
  post 'department', to: 'department#create', as: 'department_post'
  post 'activate_department', to: 'department#activate', as: 'activate_department'
  post 'deactivate_department', to: 'department#deactivate', as: 'deactivate_department'
end
