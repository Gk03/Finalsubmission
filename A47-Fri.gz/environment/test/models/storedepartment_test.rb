require 'test_helper'

class StoredepartmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
