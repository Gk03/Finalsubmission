require 'test_helper'

class DepartmentControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get department_new_url
    assert_response :success
  end

  test "should get create" do
    get department_create_url
    assert_response :success
  end

  test "should get activate" do
    get department_activate_url
    assert_response :success
  end

  test "should get deactivate" do
    get department_deactivate_url
    assert_response :success
  end

end
