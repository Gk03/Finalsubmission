require 'test_helper'

class StoreControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get store_new_url
    assert_response :success
  end

  test "should get list" do
    get store_list_url
    assert_response :success
  end

  test "should get update" do
    get store_update_url
    assert_response :success
  end

end
